# KALAVAI: Cooperative LLM Training via Independent Specialists
## NeurIPS 2026 Supplementary Material

This archive contains all experiment scripts, evaluation utilities, and result
artefacts needed to reproduce the results reported in the paper.

---

## Contents

    experiments/    Python scripts for all experiments reported in the paper
    results/        JSON result files for every experimental condition
    pyproject.toml  Package configuration with dependencies
    README.md       This file

---

## Environment Setup

Python 3.11+ required.

    pip install torch>=2.0 transformers>=4.40 datasets>=2.18 accelerate peft scipy matplotlib tqdm

All base models (Pythia-410M, Pythia-1B, Pythia-6.9B, Qwen-2.5-1.5B) are
downloaded automatically from HuggingFace Hub on first run.

---

## Key Files

| File | Purpose |
|------|---------|
| experiments/kalavai_eval_utils.py | Shared evaluation protocol (per-domain equal-weight, bs=4) |
| experiments/kalavai_pythia_experiment.py | Main 410M result (Table 1, ~30 min on one GPU) |
| experiments/kalavai_pythia_1b_experiment.py | 1B result (Table 1) |
| experiments/kalavai_pythia_6b_experiment.py | 6.9B result (Table 1) |
| experiments/kalavai_qwen_experiment.py | Qwen-1.5B result (Table 1) |
| experiments/kalavai_pythia_monolithic_baseline.py | Equal-compute monolithic baseline (Table 2) |
| experiments/kalavai_training_duration_crossover.py | Training duration crossover (Table 3, Figure 1B) |
| experiments/kalavai_pythia_ablation_freeze.py | Freeze depth ablation (Appendix D) |
| experiments/kalavai_pythia_ablation_router.py | Router architecture ablation (Section 4.6) |
| experiments/kalavai_shared_init_ablation.py | Shared initialisation ablation (Section 4.8) |
| experiments/kalavai_20contributor_experiment.py | 20-contributor federation (Section 4.10) |
| experiments/kalavai_phase2_exp1.py | Cross-lingual fusion — Exp 1 (Section 4.7) |
| experiments/kalavai_phase2_exp2.py | Private-domain fusion — Exp 2 (Section 4.7) |
| experiments/kalavai_regression_p1_2domain.py | Regression extension P1: 2-domain (code+science, Table 5 row 3) |
| experiments/kalavai_regression_p2_4domain.py | Regression extension P2: 4-domain (code+science+fiction+legal, Table 5 row 7) |
| experiments/item1_regression_fit.py | OLS fit for divergence-gain regression (Figure 5, Table 5) |
| experiments/kalavai_pythia_benchmarks.py | Downstream benchmarks at 410M (Appendix C) |
| experiments/kalavai_pythia_1b_benchmarks.py | Downstream benchmarks at 1B (Appendix C) |
| experiments/kalavai_inference_benchmark.py | Inference latency (Appendix I) |

---

## Quickstart — Reproduce Main 410M Result

    python experiments/kalavai_pythia_experiment.py

Expected output: three specialist training runs (code/science/fiction),
router training (500 steps), and evaluation. Takes approximately 30 minutes
on a consumer GPU. Results saved to results/pythia/.

All pre-computed result JSON files are included in results/ so figure
generation scripts can be run without re-running training.

---

## Reproduce Regression Extension Points

Two additional experiments fill the divergence gaps in Table 5:

    # P1: 2-domain (code + science, div ≈ 10.77%, gain +6.22%)
    python experiments/kalavai_regression_p1_2domain.py

    # P2: 4-domain (code + science + fiction + legal, div ≈ 19.84%, gain +14.71%)
    python experiments/kalavai_regression_p2_4domain.py

    # Refit OLS regression and regenerate Figure 5
    python experiments/item1_regression_fit.py

Pre-computed results: results/regression_extension/p1_2domain_summary.json
                      results/regression_extension/p2_4domain_summary.json

---

## Reproduce Figures

All figure generation scripts read from pre-computed result JSON files:

    python experiments/kalavai_regen_figures_v2.py      # Phase 1 figures
    python experiments/kalavai_phase2_figures.py         # Phase 2 figures
    python experiments/kalavai_regression_scatter_v2.py  # Figure 5 (divergence-gain scatter)
    python experiments/item1_regression_fit.py           # Figure 5 with n=8 OLS fit

Figures are written to paper/figures/.

---

## Evaluation Protocol

All results use the per-domain equal-weight evaluation implemented in
experiments/kalavai_eval_utils.py. The evaluation protocol is:

1. Evaluate each domain separately at batch size 4
2. Compute equal-weight average: (L_code + L_science + L_fiction) / 3
3. Report improvement as (L_specialist - L_MoE) / L_specialist * 100

See Appendix F of the paper for the full description including the two
evaluation bugs found during development and their corrections.

---

## Results Index

Pre-computed results are in results/ and cover:

- results/pythia/                   Phase 1: 410M (3 seeds each)
- results/pythia/pythia_1b/         Phase 1: 1B (3 seeds each)
- results/pythia_6b/                Phase 1: 6.9B (3 seeds)
- results/real/                     Qwen-1.5B (3 seeds)
- results/phase2/                   Cross-lingual, private-domain, 20-contributor
- results/regression_extension/     P1 (2-domain) and P2 (4-domain) regression extension (3 seeds each)
- results/analysis/                 Derived analyses (regression fit, LoRA ablation, etc.)
